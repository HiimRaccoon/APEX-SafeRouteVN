"""Implemented HTTP endpoints."""
