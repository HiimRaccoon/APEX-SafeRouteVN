"""FastAPI transport."""
